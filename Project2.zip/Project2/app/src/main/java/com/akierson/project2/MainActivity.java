package com.akierson.project2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.Random;

import static android.preference.PreferenceManager.getDefaultSharedPreferences;

public class MainActivity extends Activity {

    // The following are used for the shake detection
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private ShakeDetector mShakeDetector;

    // Create Random generator
    Random rand = new Random();

    SharedPreferences settings;

    boolean explicit;
    boolean pessimism;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ShakeDetector initialization
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mAccelerometer = mSensorManager
                .getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        mShakeDetector = new ShakeDetector();
        mShakeDetector.setOnShakeListener(new ShakeDetector.OnShakeListener() {
        @Override
            public void onShake(int count) {
                /*
                 * The following method, "handleShakeEvent(count):" is a stub //
                 * method you would use to setup whatever you want done once the
                 * device has been shook.
                 */
                handleShakeEvent(count);
            }
        });
        settings = getSharedPreferences(String.valueOf(R.xml.pref_general), MODE_PRIVATE);

        boolean explicit = settings.getBoolean(String.valueOf(R.string.explicit), false);

        Log.d("*****", "Working:" + String.valueOf(explicit));
        boolean pessimism = settings.getBoolean(String.valueOf(R.string.pessimistic), false);
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.settings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        } else {
            return super.onOptionsItemSelected(item);
        }
        return true;
    }

    // Randomly selects a new text for the 8 ball
    private void handleShakeEvent(int count) {
        TextView textView = findViewById(R.id.textview);
        // Get Explicit, Sad
        settings = getSharedPreferences(String.valueOf(R.xml.pref_general), MODE_PRIVATE);

        boolean explicit = settings.getBoolean(String.valueOf(R.string.explicit), false);
        boolean pessimism = settings.getBoolean(String.valueOf(R.string.pessimistic), false);

        String prediction;
        if (explicit) {
            prediction = getResources().getStringArray(R.array.explicit_answers)[rand.nextInt(19)];
        } else if (pessimism) {
            prediction = getResources().getStringArray(R.array.pessimistic_answers)[rand.nextInt(19)];
        } else if (explicit && pessimism) {
            prediction = getResources().getStringArray(R.array.pessimistic_explicit_answers)[rand.nextInt(19)];
        } else {
            prediction = getResources().getStringArray(R.array.answers)[rand.nextInt(19)];
        }
        textView.setText(prediction);
    }

    @Override
    public void onResume() {
        super.onResume();
        // Add the following line to register the Session Manager Listener onResume
        mSensorManager.registerListener(mShakeDetector, mAccelerometer,	SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    public void onPause() {
        // Add the following line to unregister the Sensor Manager onPause
        mSensorManager.unregisterListener(mShakeDetector);
        super.onPause();
    }
}

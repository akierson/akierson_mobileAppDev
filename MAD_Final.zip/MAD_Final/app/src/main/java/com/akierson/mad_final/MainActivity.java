package com.akierson.mad_final;

import android.app.Activity;
import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.net.URI;
import java.net.URL;
import java.sql.Array;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public boolean findPizza(View view) {
        TextView pizza_descr_tv = findViewById(R.id.pizza_descr);
        ImageView pizza_image = findViewById(R.id.pizza_view);
        TextView pizza_name = findViewById(R.id.pizza_name);
        ToggleButton pizza_sauce = findViewById(R.id.sauce);
        RadioButton thin_crust = findViewById(R.id.thin_crust);
        RadioButton thick_crust = findViewById(R.id.thick_crust);
        String crust;
        if (!thin_crust.isChecked() && !thick_crust.isChecked()) {
            Toast.makeText(this, R.string.error_no_crust, Toast.LENGTH_SHORT).show();
            return false;
        } else if (thin_crust.isChecked()) {
            crust = getString(R.string.thin_crust);
        } else {
            crust = getString(R.string.thick_crust);
        }
        Spinner pizza_size = findViewById(R.id.spinner);
        String toppings = "";
        CheckBox sausage = findViewById(R.id.sausage);
        if (sausage.isChecked()){
            toppings = getString(R.string.sausage) + ", ";
        }
        CheckBox pepperoni = findViewById(R.id.pepperoni);
        if (pepperoni.isChecked()){
            toppings += getString(R.string.pepperoni) + ", ";
        }
        CheckBox mushrooms = findViewById(R.id.mushrooms);
        if (mushrooms.isChecked()){
            toppings += getString(R.string.mushrooms) + ", ";
        }
        CheckBox green_peppers = findViewById(R.id.green_peppers);
        if (green_peppers.isChecked()){
            toppings += getString(R.string.green_peppers) + ", ";
        }
        toppings += "and cheese.";
        Spinner size = findViewById(R.id.spinner);
        Switch gluten_free = findViewById(R.id.gluten_free);
        String gluten_free_text = "";
        if (gluten_free.isChecked()){
            gluten_free_text = getString(R.string.gluten_free) + " ";
        }

        String pizz_descr = "Your " + pizza_name.getText() + " is a " + gluten_free_text + pizza_size.getSelectedItem() + " " + crust + " pizza. It has " + toppings;

        int image;
        if ((sausage.isChecked() || pepperoni.isChecked()) && (mushrooms.isChecked() || green_peppers.isChecked())) {
            image = R.drawable.pizza_supreme;
        } else if (sausage.isChecked() || pepperoni.isChecked()) {
            image = R.drawable.pizza_meat;
        } else if (mushrooms.isChecked() || green_peppers.isChecked()) {
            image = R.drawable.pizza_veggie;
        } else {
            image = R.drawable.pizza_cheese;
        }

        pizza_image.setImageResource(image);
        pizza_descr_tv.setText(pizz_descr);

        Button find_pizza = findViewById(R.id.find_pizza);
        find_pizza.setVisibility(View.VISIBLE);

        return true;
    }


    public void findPizzaPlace(View view) {
        Switch gf = findViewById(R.id.gluten_free);
        RadioButton thin_crust = findViewById(R.id.thin_crust);

        String pizza_url;
        String pizza_place;
        if (gf.isChecked()) {
            pizza_url = "https://bossladypizza.com/";
            pizza_place = "Boss Lady Pizza";
        } else if (thin_crust.isChecked()) {
            pizza_url = "https://localeboulder.com/";
            pizza_place = "Pizza Locale";
        } else {
            pizza_url = "https://backcountrypizzaandtaphouse.info/";
            pizza_place = "Back Country Pizza";
        }

//        Intent intent = new Intent(ACTION.E PizzaPlace.class);
//        intent.putExtra("url", pizza_url);
//        intent.putExtra("place", pizza_place);
//        intent.;
    }
}

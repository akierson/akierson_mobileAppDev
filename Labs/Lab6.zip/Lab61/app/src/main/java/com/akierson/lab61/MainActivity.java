package com.akierson.lab61;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void giveMeal(View view) {
        RadioGroup mealTime = findViewById(R.id.radioGroup);
        CheckBox vegetarianCheck = findViewById(R.id.checkBox_veg);
        CheckBox dairyCheck = findViewById(R.id.checkBox_dairy);
        CheckBox glutenCheck = findViewById(R.id.checkBox_gluten);
        TextView mealLabel = findViewById(R.id.textView);
        ImageView image = findViewById(R.id.imageView);

        int meal = mealTime.getCheckedRadioButtonId();
        String mealString = "";

        switch (meal) {
            case R.id.radioButton_br:
                // Breakfast - eggs, bacon, and toast
                String eggs = "Eggs,\n";
                String bacon = "Bacon,\n";
                String toast = "Toast";
                String withButter = " with Butter";
                image.setImageResource(R.drawable.eggs_bacon);
                // dairy free - change out butter with fake butter
                if (dairyCheck.isChecked()) {
                   withButter = " with fake Butter";
                } // vegetarian - remove bacon
                if (vegetarianCheck.isChecked()){
                    bacon = "";
                    image.setImageResource(R.drawable.eggs_toast);
                }
                // Gluten Free - replace bread with gluten - free bread
                if (glutenCheck.isChecked()){
                    toast = "Gluten Free Toast";
                }
                mealString = eggs + bacon + toast + withButter;
                
                break;
            case R.id.radioButton_lu:
                // Lunch - turkey sandwich
                String meat = "Turkey ";
                String cheese = "Cheese ";
                String bread = "White.";
                image.setImageResource(R.drawable.sandwich);
                // dairy free - place cheese with avocado
                if (dairyCheck.isChecked()){
                    cheese = "Avocado ";
                }
                // vegetarian - replace with pasta
                if (vegetarianCheck.isChecked()){
                    meat = "Tempeh ";
                }
                // Gluten Free - replace with salad
                if (glutenCheck.isChecked()) {
                    bread = "Rice Bread";
                }
                mealString = meat + "with " + cheese + "on " + bread;
                break;
            case R.id.radioButton_di:
                //Dinner - Fried chicken with Waffles
                String chicken = "Fried Chicken ";
                String waffles = "Waffles.";
                image.setImageResource(R.drawable.chicken_waffles);
                // vegetarian
                if (vegetarianCheck.isChecked()) {
                    chicken = "Waffles ";
                    image.setImageResource(R.drawable.waffles);
                }
                // Gluten Free
                if (glutenCheck.isChecked()){
                    waffles = "Fried Chicken.";
                    image.setImageResource(R.drawable.fried_chicken);
                }
                mealString = chicken + "and " + waffles;
                break;
            case -1:
                // Make toast if radio has no selection
                Context context = getApplicationContext();
                Toast toastError = Toast.makeText(context, "No Meal Time Selected!", Toast.LENGTH_SHORT);
                toastError.show();
        }
        mealLabel.setText(mealString);
    }


}

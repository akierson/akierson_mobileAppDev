package com.akierson.lab7;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ReceiveBeerActivity extends Activity {

    private int beer;
    private int beerImg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_beer);

        Intent intent = getIntent();

        beer = intent.getIntExtra("beer", 0);
        beerImg = intent.getIntExtra("beerImage", 0);

        TextView beerName = findViewById(R.id.textView4);
        ImageView beerImage = findViewById(R.id.imageView);

        beerName.setText(beer);
        beerImage.setImageResource(beerImg);
    }
}

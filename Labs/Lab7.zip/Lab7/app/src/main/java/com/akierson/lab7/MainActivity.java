package com.akierson.lab7;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class MainActivity extends Activity {

    private BeerChoice myBeerChoice = new BeerChoice();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findBeer(View view){
        // Get Buttons
        RadioButton radio1 = findViewById(R.id.radioButton);
        RadioButton radio2 = findViewById(R.id.radioButton2);
        RadioButton radio3 = findViewById(R.id.radioButton4);

        Boolean choice1 = radio1.isChecked();
        Boolean choice2 = radio2.isChecked();
        Boolean choice3 = radio3.isChecked();

        // Set Beer Choices
        myBeerChoice.setBeer(choice1, choice2, choice3);

        Log.i("Beer", String.valueOf(myBeerChoice.getBeer()));
        Log.i("BeerImg", String.valueOf(myBeerChoice.getBeerImage()));


        // Get Info from class
        int beerName = myBeerChoice.getBeer();
        int beerImg = myBeerChoice.getBeerImage();

        Intent intent = new Intent(this, ReceiveBeerActivity.class);
        intent.putExtra("beer", beerName);
        intent.putExtra("beerImage", beerImg);

        startActivity(intent);

    }
}

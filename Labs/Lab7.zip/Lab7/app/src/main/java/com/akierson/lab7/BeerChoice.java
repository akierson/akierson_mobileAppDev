package com.akierson.lab7;

public class BeerChoice {
    private int beer;
    private int beerImage;

    public void setBeer(boolean choice, boolean choice2, boolean choice4){
        if (choice) {
            if (choice2){
                if (choice4){
                    beer = R.string.answer111;
                    beerImage = R.drawable.session_ipa;
                } else {
                    beer = R.string.answer112;
                    beerImage = R.drawable.ipa;
                }
            } else {
                if (choice4){
                    beer = R.string.answer121;
                    beerImage = R.drawable.altbier;
                } else {
                    beer = R.string.answer122;
                    beerImage = R.drawable.russian_imperial_stout;
                }
            }
        } else {
            if (choice2){
                if (choice4){
                    beer = R.string.answer211;
                    beerImage = R.drawable.pilsner;
                } else {
                    beer = R.string.answer212;
                    beerImage = R.drawable.blonde_ale;
                }
            } else {
                if (choice4){
                    beer = R.string.answer221;
                    beerImage = R.drawable.traditional_bock;
                } else {
                    beer = R.string.answer222;
                    beerImage = R.drawable.stout;
                }
            }
        }
    }

    public int getBeer() {
        return beer;
    }

    public int getBeerImage() {
        return beerImage;
    }
}


package com.akierson.lab5;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void flavorMe(View view) {
        // Get objects in view
        EditText name = findViewById(R.id.editText);
        ImageView flavorImage = findViewById(R.id.imageView);
        TextView flavorText = findViewById(R.id.textView);

        int flavor = name.getText().toString().length() %3;
        switch (flavor) {
            case 0:
                flavorImage.setImageResource(R.drawable.food0);
                flavorText.setText("B̨̟̖͎̤̤̺ͭ̍ͨͨ̅ͩ̚ ̴͍ͪ̊R͖̒͗̚ ̸̩̝̫͈̒̈̂ͨÉ̥ ̙̬͓ͨ̊ͫ̀A̴̳̙͔̾ͯ̑ ͖̬͈̤̠͔ͬ̄͞D̝͈͈͇͋͑͆͋");
                break;
            case 1:
                flavorImage.setImageResource(R.drawable.food1);
                flavorText.setText("B̡͔̺͔̙̔̓͑ ̥̩̲ͫͅͅR̴̹̭̗̳̱̹̄͐̓̆ ̦Ö͆̂ͮͥ̏ͫͨ̕ ̭̳̗̎ͣ͌̏̎T̻̱̑̅ͪ ̡͈̠̥̥̙̱ͭ͗Ḥ̙͙̺͕͂ͣ ̹̞͕̹̟̒̾ͦ̾̎̚͞ͅͅẸ̛͓͑̆͌̇̋ͮ ̜̹̲̪̬̣̎̏Ř̡͖͎̳̩̟̭");
                break;
            case 2:
                flavorImage.setImageResource(R.drawable.food2);
                flavorText.setText("M̨̭͇͔̤ͣ ̛̤͔͔͖̠͋̋ͫ̚E̳͖ͯͧ̂͐̔̀ ̸̭͔̺ͮ̆͑̾͗̚A͖̝͔̩̗ ̤͋ͯ͗͋̓ͤͭT͒ͩ͂ͫ҉͙̯̳̥͇̪ ̻̫͕̙̫͛");
                break;
            default:
                break;
        }


    }
}
